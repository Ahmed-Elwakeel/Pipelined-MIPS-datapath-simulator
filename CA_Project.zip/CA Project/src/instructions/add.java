package instructions;

import registers.*;

public class add {
	
	int opcode = 0;
	Register rs;
	Register rt;
	Register rd;
	
	public add(Register rs, Register rt, Register rd) {
		this.rs = rs;
		this.rt = rt;
		this.rd = rd;
	}
	
	public void execute() {
		rd.setValue(rs.getValue() + rt.getValue());
	}

}
