package registers;

public class a3 implements Register {
	
	String name = "$a3";
	int value = 0;
	

	public void increment() {
		this.value++;
	}

	public void decrement() {
		this.value--;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	
}
