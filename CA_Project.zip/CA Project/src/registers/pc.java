package registers;

public class pc implements Register {
	
	String name = "pc";
	int value = 0;
	

	public void increment() {
		this.value++;
	}

	public void decrement() {
		this.value--;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	
}
