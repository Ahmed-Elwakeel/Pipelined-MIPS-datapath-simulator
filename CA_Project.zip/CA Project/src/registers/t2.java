package registers;

public class t2 implements Register {
	
	String name = "$t2";
	int value = 0;
	

	public void increment() {
		this.value++;
	}

	public void decrement() {
		this.value--;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
}
