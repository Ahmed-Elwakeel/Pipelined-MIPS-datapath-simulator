package registers;

public interface Register {
	
	public void increment();
	
	public void decrement();
	
	public int getValue();
	
	public void setValue(int value);

	public String getName();
	
}
