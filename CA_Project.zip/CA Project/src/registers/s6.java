package registers;

public class s6 implements Register {
	
	String name = "$s6";
	int value = 0;
	

	public void increment() {
		this.value++;
	}

	public void decrement() {
		this.value--;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
}
