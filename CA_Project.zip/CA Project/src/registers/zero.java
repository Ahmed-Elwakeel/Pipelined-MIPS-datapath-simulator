package registers;

public class zero implements Register {
	
	String name = "$0";
	int value = 0;
	
	public zero() {
		
	}
	

	public void increment() {
		
	}

	public void decrement() {
		
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {

	}
	public String getName() {
		return name;
	}
}
