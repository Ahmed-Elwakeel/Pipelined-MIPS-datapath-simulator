package registers;

public class fp implements Register {
	
	String name = "$fp";
	int value = 0;
	

	public void increment() {
		this.value++;
	}

	public void decrement() {
		this.value--;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
}
