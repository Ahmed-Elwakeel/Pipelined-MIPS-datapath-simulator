import java.util.Scanner;

import registers.*;
import instructions.*;



public class Simulator {
	
	Register register_memory [] = new Register[32];
	int pc = 0;
	int [][] main_memory = new int[2][100];
	
	public Simulator() {
		this.initRegisterMemory();
	}
	
	public void initRegisterMemory(){
		register_memory[0] = new zero();
		register_memory[1] = new temp();
		register_memory[2] = new v0();
		register_memory[3] = new v1();
		register_memory[4] = new a0();
		register_memory[5] = new a1();
		register_memory[6] = new a2();
		register_memory[7] = new a3();
		register_memory[8] = new t0();
		register_memory[9] = new t1();
		register_memory[10] = new t2();
		register_memory[11] = new t3();
		register_memory[12] = new t4();
		register_memory[13] = new t5();
		register_memory[14] = new t6();
		register_memory[15] = new t7();
		register_memory[16] = new s0();
		register_memory[17] = new s1();
		register_memory[18] = new s2();
		register_memory[19] = new s3();
		register_memory[20] = new s4();
		register_memory[21] = new s5();
		register_memory[22] = new s6();
		register_memory[23] = new s7();
		register_memory[24] = new t8();
		register_memory[25] = new t9();
		register_memory[26] = new temp();
		register_memory[27] = new temp();
		register_memory[28] = new gp();
		register_memory[29] = new sp();
		register_memory[30] = new fp();
		register_memory[31] = new ra();
	}
	
	public Register checkRegister(String s) {
		for(int i = 0; i < this.register_memory.length; i++) {
			if (s.equals(this.register_memory[i].getName())) {
				return this.register_memory[i];
			}
		}
		return null;
	}
	
	public void run(String s) {
		String a [] = s.split(" ", 2);
		if(a[0].equals("add")) {
			String b [] = a[1].split(", ", 3);
			Register x = this.checkRegister(b[1]);
			Register y = this.checkRegister(b[2]);
			Register z = this.checkRegister(b[0]);
			add instruction = new add(x, y, z);
			instruction.execute();
		}
	}
	
	public void addData(String s) {
		
	}
	
	public int getData(){
		return register_memory[9].getValue();
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String program = sc.nextLine();
		Simulator test = new Simulator();
		test.run(program);
		
		
	}

}
